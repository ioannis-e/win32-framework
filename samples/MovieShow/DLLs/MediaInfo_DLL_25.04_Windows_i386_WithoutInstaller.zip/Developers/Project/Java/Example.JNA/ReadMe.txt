MediaInfo DLL binding for Java

1. Download JNA (http://jna.dev.java.net)

2. Make sure the MediaInfo native library is in your library path
    Windows: copy MediaInfo.dll into you working directory
    Linux: install libmediainfo using the package for your distro

3. You can test the "HowToUse_Dll" example (compile, run)
